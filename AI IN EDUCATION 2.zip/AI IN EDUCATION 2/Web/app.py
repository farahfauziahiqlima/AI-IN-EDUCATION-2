import joblib
import requests
import os
from flask import Flask, render_template, request, jsonify, session, redirect, flash, url_for
from flask_session import Session
from flask_cors import CORS
import jwt

API = os.environ.get('API_URL')
SECRET_KEY = os.environ.get('SECRET_KEY')
DIR = os.path.dirname(__file__)
MODEL = joblib.load(os.path.join(DIR, './models/svm_model.joblib'))

app = Flask(__name__,
            static_url_path='', 
            static_folder='static',
            template_folder='templates')

sess = Session()
app.secret_key = SECRET_KEY
app.config['SESSION_TYPE'] = 'filesystem'
sess.init_app(app)
CORS(app)

def is_user_authenticated():
    return 'token' in session

@app.before_request
def check_authentication():
    if request.endpoint not in ['login', 'register', 'index', 'static'] and not is_user_authenticated():
        return redirect('/login')

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'GET':
        return render_template('register.html')
    elif request.method == 'POST':
        id_lecturer = request.form.get('idLecturer')
        name = request.form.get('name')
        password = request.form.get('password')

        try:
            endpoint = 'auth/register'

            full_url = f"{API}/{endpoint}"

            response = requests.post(full_url, json={
                'idLecturer': id_lecturer,
                'name': name,
                'password': password
            })

            if response.status_code == 200 or response.status_code == 201:
                token = response.json().get('token')
                session['token'] = token
                return redirect('/fitur')
            else:
                msg = response.json().get('message')
                flash(f"Register failed. {msg}", 'error')
                return redirect('/register')

        except requests.exceptions.RequestException as e:
            print(e)
            return redirect('/register')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'GET':
        return render_template('login.html')
    elif request.method == 'POST':

        id_lecturer = request.form.get('idLecturer')
        password = request.form.get('password')

        try:
            endpoint = 'auth/login'

            full_url = f"{API}/{endpoint}"

            response = requests.post(full_url, json={
                'idLecturer': id_lecturer,
                'password': password
            })

            if response.status_code == 200:
                token = response.json().get('token')
                session['token'] = token
                return redirect('/fitur')
            else:
                msg = response.json().get('message')
                flash(f"Login failed. {msg}", 'error')
                return redirect('/login')

        except requests.exceptions.RequestException as e:
            return redirect('/login')

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/profile')
def profile():
    if 'token' not in session:
        return redirect(url_for('login'))

    try:
        token = session['token']
        decoded_token = jwt.decode(token, SECRET_KEY, algorithms=['HS256'])

        name = decoded_token.get('name')
        idLecturer = decoded_token.get('idLecturer')

        return render_template('profile.html', name=name, idLecturer=idLecturer)

    except jwt.ExpiredSignatureError:
        session.clear()
        flash('Session expired. Please log in again.', 'error')
        return redirect(url_for('login'))

    except jwt.InvalidTokenError:
        # Handle invalid token
        session.clear()
        flash('Invalid token. Please log in again.', 'error')
        return redirect(url_for('login'))

@app.route('/repeat-paper/result')
def repeat_paper_result():
    return render_template('repeat-paper-result.html')

@app.route('/grade-result')
def grade_result():
    return render_template('grade-result.html')

@app.route('/pathology-mark/result')
def pathology_result():
    return render_template('pathology-result.html')

@app.route('/microbiology-mark/result')
def microbiology_result():
    return render_template('microbiology-result.html')

@app.route('/pharmacology-mark/result')
def pharmacology_result():
    return render_template('pharmacology-result.html')

@app.route('/dental-material-science/result')
def dental_material_science_result():
    return render_template('dental-material-science-result.html')

@app.route('/fitur')
def fitur():
    if not is_user_authenticated:
        return redirect('/login')
    return render_template('fitur.html')

@app.route('/repeat-paper', methods=['GET'])
def repeat_paper():
    return render_template('repeat-paper.html')

@app.route('/anatomy-mark', methods=['GET'])
def anatomy_mark():
    return render_template('anatomy-mark.html')

@app.route('/physiology-mark', methods=['GET'])
def physiology_mark():
    return render_template('physiology-mark.html')

@app.route('/biochemistry-mark', methods=['GET'])
def biochemistry_mark():
    return render_template('biochemistry-mark.html')

@app.route('/oralbiology-mark', methods=['GET'])
def oralbiology_mark():
    return render_template('oralbiology-mark.html')

@app.route('/pathology-mark', methods=['GET'])
def pathology_mark():
    return render_template('pathology-mark.html')

@app.route('/microbiology-mark', methods=['GET'])
def microbiology_mark():
    return render_template('microbiology-mark.html')

@app.route('/pharmacology-mark', methods=['GET'])
def pharmacology_mark():
    return render_template('pharmacology-mark.html')

@app.route('/dental-material-science', methods=['GET'])
def dental_material_science():
    return render_template('dental-material-science.html')

@app.route('/predict', methods=['POST'])
def predict():
    data = request.get_json()  
    age = int(data['age'])
    total_semesters = int(data['total_semesters'])
    average_gpa = float(data['average_gpa'])
    final_gpa = float(data['final_gpa'])

    prediction_result = MODEL.predict([[age, total_semesters, average_gpa, final_gpa]])[0]

    return {'prediction': prediction_result}

if __name__ == '__main__':
    app.run(debug=True)
