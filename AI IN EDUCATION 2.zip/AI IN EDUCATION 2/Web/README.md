# How to run

1. Buka terminal lalu ketikan

```zsh
pip install -r requirements.txt
```

2.  Setelah proses instalasi module selesai dengan sukses, lalu jalankan perintah ini pada terminal untuk menjalankan flask app

```zsh
python app.py
```

3. Setelah muncul ` * Running on http://127.0.0.1:5000`.Lalu copy dan buka pada browser url tersebut. 
*catatan: port bisa saja berbeda dari `:5000`