require("dotenv").config();
const mongoose = require("mongoose");
const app = require("./src/app");
const chalk = require("chalk");

const PORT = process.env.PORT || 3001;

mongoose.connect(process.env.MONGODB_URL)
  .then(() => {
    console.log(chalk.green("MongoDB connection successful"));
    startServer();
  })
  .catch((err) => {
    console.error(chalk.red("Error connecting to MongoDB:"), err.message);
  });

function startServer() {
  app.listen(PORT, () => {
    console.log(chalk.blue(`Server is running at http://localhost:${PORT}`));
  });
}
