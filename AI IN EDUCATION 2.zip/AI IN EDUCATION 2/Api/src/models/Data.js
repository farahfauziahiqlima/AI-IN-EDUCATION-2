const mongoose = require("mongoose");
const { Schema } = mongoose;

const DataSchema = new Schema({
  name: {
    type: String,
    required: true,
  },
  age: {
    type: Number,
    required: true,
  },
  total_semesters: {
    type: Number,
    required: true,
  },
  average_gpa: {
    type: Number,
    required: true,
  },
  final_gpa: {
    type: Number,
    required: true,
  },
  result: {
    type: String,
    required: true,
  },
});
const Data = mongoose.model("Data", DataSchema);

module.exports = Data;
