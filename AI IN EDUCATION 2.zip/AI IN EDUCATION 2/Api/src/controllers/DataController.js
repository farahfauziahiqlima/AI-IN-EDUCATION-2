const Data = require("../models/Data");

const saveData = async (req, res, next) => {
    const { name, age, total_semesters, average_gpa, final_gpa, result } =
        req.body;

    try {
        await Data.create({
            name,
            age,
            total_semesters,
            average_gpa,
            final_gpa,
            result,
        });

        res.status(201).json({
            message: "Success, data created",
        });
    } catch (err) {
        res.status(400).json({
            message: err.message,
        });
    }
};

const getAllResultData = async (req, res, next) => {
    try {
        const result = await Data.find();

        res.status(200).json({
            data: result,
        });
    } catch (error) {
        res.status(500).json({
            message: error.message,
        });
    }
};

module.exports = {
    saveData,
    getAllResultData,
};
