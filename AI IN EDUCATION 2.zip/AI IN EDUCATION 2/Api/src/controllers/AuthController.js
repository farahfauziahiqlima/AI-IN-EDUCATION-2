const User = require("../models/User");
const bcrypt = require("bcryptjs");
const chalk = require("chalk");
const jwt = require("jsonwebtoken");
const SECRET_KEY = process.env.SECRET_KEY

const register = async (req, res, next) => {
    try {
        let hashedPass = await bcrypt.hash(req.body.password, 10);

        let user = new User({
            idLecturer: req.body.idLecturer,
            name: req.body.name,
            password: hashedPass,
        });

        await user.save();

        const token = jwt.sign({ idLecturer: user.idLecturer, name: user.name }, SECRET_KEY, { expiresIn: '1h' });

        res.status(201).json({
            message: "User Added Successfully!",
            token: token
        });
    } catch (error) {
        console.log(chalk.red(`error: ${error}`));
        res.status(400).json({
            message: error.message,
        });
    }
};

const login = async (req, res, next) => {
    const idLecturer = req.body.idLecturer;
    const password = req.body.password;

    try {
        const user = await User.findOne({ idLecturer: idLecturer });

        if (!user) {
            res.status(404).json({
                message: "User not found",
            });
            return;
        }

        const match = await bcrypt.compare(password, user.password);

        if (!match) {
            res.status(400).json({
                message: "Incorrect email or password",
            });
            return;
        }

        const token = jwt.sign({ idLecturer: user.idLecturer, name: user.name }, SECRET_KEY, { expiresIn: '1h' });

        res.status(200).json({
            message: "Login successful",
            token: token,
        });
    } catch (error) {
        console.log(chalk.red(`error: ${error}`));
        res.status(500).json({
            message: error.message,
        });
    }
};

const getAllUsers = async (req, res, next) => {
    try {
        const users = await User.find();
        res.status(200).json({
            users: users,
        });
    } catch (error) {
        res.status(500).json({
            message: error.message,
        });
    }
};

module.exports = {
    register,
    login,
    getAllUsers,
};