const express = require("express");
const cors = require("cors");
const authRoutes = require("./routes/AuthRoutes");
const dataRoutes = require("./routes/DataRoutes");

const app = express();

app.use(cors());
app.use(express.json());

// test api
app.get('/ping', (req, res) => {
    res.json({
        'message': 'Hello World!',
    });
});

app.use("/auth", authRoutes);
app.use("/data", dataRoutes);

module.exports = app;