const express = require("express");
const {
  saveData,
  getAllResultData,
} = require("../controllers/DataController");

const dataRouter = express.Router();

dataRouter.post("/save", saveData);
dataRouter.get("/all", getAllResultData);

module.exports = dataRouter;
