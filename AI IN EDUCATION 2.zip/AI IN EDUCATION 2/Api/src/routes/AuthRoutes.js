const express = require("express");
const {
  register,
  login,
  getAllUsers
} = require("../controllers/AuthController");

const authRouter = express.Router();

authRouter.post("/register", register);
authRouter.post("/login", login);

// remove later, just to check that the user is stored(registered) successfully
authRouter.get("/getallusers", getAllUsers);

module.exports = authRouter;
